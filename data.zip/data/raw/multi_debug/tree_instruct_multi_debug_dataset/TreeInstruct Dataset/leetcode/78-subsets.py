"""
<problem>
Problem Link: https://leetcode.com/problems/subsets/

Given an integer array nums of unique elements, return all possible subsets (the power set).
The solution set must not contain duplicate subsets. Return the solution in any order.

Example 1:
Input: nums = [1,2,3]
Output: [[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]

Example 2:
Input: nums = [0]
Output: [[],[0]]
 
Constraints:
1 <= nums.length <= 10
-10 <= nums[i] <= 10
All the numbers of nums are unique.
</problem>
"""
class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        self.res = []
        
        def create_subset(nums, index, subset=[]):
            self.res.append(subset)
            if index >= len(nums):
                return
            
            for i in range(index, len(nums)):
                create_subset(nums, i+1, subset + [nums[i]])
            
        create_subset(nums, 0)
        return self.res
